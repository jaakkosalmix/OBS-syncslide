#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d "dist/SyncSlide for OBS.app" ]; then
  echo "App not found. Building app first..."
  chmod +x build_mac.sh
  ./build_mac.sh
fi

rm -rf dmg_temp
mkdir -p dmg_temp
cp -R "dist/SyncSlide for OBS.app" dmg_temp/
ln -s /Applications dmg_temp/Applications || true

hdiutil create -volname "SyncSlide for OBS" -srcfolder dmg_temp -ov -format UDZO "dist/SyncSlide_for_OBS.dmg"
rm -rf dmg_temp

echo ""
echo "DMG created:"
echo "dist/SyncSlide_for_OBS.dmg"
