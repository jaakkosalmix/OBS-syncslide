# SyncSlide for OBS - build package

## Included upgrades
- Multi-folder playlist
- Slide duration control
- Fade duration control
- Contain / cover fit mode
- OBS scene collection export
- macOS app build
- macOS DMG build
- Windows EXE build
- Windows Setup EXE script (Inno Setup)

## macOS
Double-click:
- `Build Mac App.command` to build the `.app`
- `Build Mac DMG.command` to build a `.dmg`

Outputs:
- `dist/SyncSlide for OBS.app`
- `dist/SyncSlide_for_OBS.dmg`

## Windows
Double-click:
- `build_windows.bat` to build the `.exe`
- `build_windows_setup.bat` to build the installer setup `.exe`

Windows setup requires Inno Setup installed and `iscc` available in PATH.

Outputs:
- `dist\SyncSlide for OBS.exe`
- `dist\SyncSlide_for_OBS_Setup.exe`

## OBS quick setup
Inside the app, use:
- `Export OBS scene collection…`

Then import the JSON into OBS as a scene collection and adjust if needed for your OBS version.
