\
#define MyAppName "SyncSlide for OBS"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "OpenAI User Build"
#define MyAppExeName "SyncSlide for OBS.exe"

[Setup]
AppId={{4E9A06A4-5F3F-4478-B29A-34C3A8A5A9F1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputDir=dist
OutputBaseFilename=SyncSlide_for_OBS_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
SetupIconFile=syncslide_icon.ico

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
Source: "dist\SyncSlide for OBS\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
