#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
pyinstaller --noconfirm --windowed --icon=syncslide_icon.icns --name "SyncSlide for OBS" syncslide_obs_app.py
echo ""
echo "Build complete:"
echo "dist/SyncSlide for OBS.app"
