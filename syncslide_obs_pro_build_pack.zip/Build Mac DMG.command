#!/bin/bash
cd "$(dirname "$0")"
chmod +x build_mac_dmg.sh
./build_mac_dmg.sh
read -n 1 -s -r -p "Press any key to close..."
