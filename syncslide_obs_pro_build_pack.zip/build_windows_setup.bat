\
@echo off
cd /d "%~dp0"

if not exist "dist\SyncSlide for OBS\SyncSlide for OBS.exe" (
  echo App build not found. Building app first...
  call build_windows.bat
)

where iscc >nul 2>nul
if errorlevel 1 (
  echo Inno Setup compiler (iscc) not found in PATH.
  echo Install Inno Setup, then run this file again.
  pause
  exit /b 1
)

iscc SyncSlide_for_OBS.iss
echo.
echo Setup created:
echo dist\SyncSlide_for_OBS_Setup.exe
pause
