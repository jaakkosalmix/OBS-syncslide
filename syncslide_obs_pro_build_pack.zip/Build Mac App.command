#!/bin/bash
cd "$(dirname "$0")"
chmod +x build_mac.sh
./build_mac.sh
read -n 1 -s -r -p "Press any key to close..."
