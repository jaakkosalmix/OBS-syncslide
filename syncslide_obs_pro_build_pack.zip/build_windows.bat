\
@echo off
cd /d "%~dp0"
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
pyinstaller --noconfirm --windowed --icon=syncslide_icon.ico --name "SyncSlide for OBS" syncslide_obs_app.py
echo.
echo Build complete:
echo dist\SyncSlide for OBS.exe
pause
